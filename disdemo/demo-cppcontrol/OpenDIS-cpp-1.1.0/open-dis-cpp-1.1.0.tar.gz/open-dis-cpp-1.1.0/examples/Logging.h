#pragma once

#include <iostream>

#define LOG_ERROR(text) \
   std::cerr << text << std::endl;

#define LOG_WARNING(text) \
   std::cerr << text << std::endl;

